# PayPal Clone
Fully responsive PayPal clone website using HTML, CSS and JavaScript.

## Languages
- HTML
- CSS
- JavaScript

## Screenshot
![Screenshot (303)](https://user-images.githubusercontent.com/93200960/215094189-9edcddf5-d423-4edd-8b5a-1b5c3ad720b4.png)

## Demo 
https://user-images.githubusercontent.com/93200960/196205915-469c1573-9332-4e33-aca6-9a2caa1c1136.mp4

## 🚀 About Me
I'm a self tought frontend web developer...

## 🔗 Links
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://karanchandekar.netlify.app/)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/karan-chandekar-a87263219/)
[![twitter](https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/karanchandekar1)
